<?php

define("DB_HOST","localhost");
define("DB_USER","marina");
define("DB_PASS","pass");
define("DB_NAME","order");

