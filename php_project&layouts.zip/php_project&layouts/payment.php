
<?php
require_once("./validatecard.php");

 $error_valid=new payment_valid ();
 $validerror=$error_valid->payment_validation(1234567891234567,"3/5",123);
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="/payment.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <title>Document</title>
</head>
    <body style="background: #1e1f26;">
  <section class="gradient-custom" >
        <div class="container my-5 py-5">
          <div class="row d-flex justify-content-center py-5">
            <div class="col-md-7 col-lg-5 col-xl-4">
              <div class="card" style="border-radius: 15px;">
                <div class="card-body p-4">

                <!-- PAYMENT_FORM -->
                  <form action="" method="POST">
                  <p> <?php echo " $validerror"?> </p>
                    <!-- CRIDIT -->
                    <div class="d-flex justify-content-between align-items-center mb-3">
                      <div class="form-outline">
                        <input type="text" id="typeText" class="form-control form-control-lg" siez="17"
                          placeholder="Card Number" minlength="19" maxlength="19" name="credit"/>
                      </div>
                      <img src="https://img.icons8.com/color/48/000000/visa.png" alt="visa" width="64px" />
                    </div>
                    <div class="d-flex justify-content-between align-items-center pb-2">
                      <!-- EXPIRE_DATE -->
                      <div class="form-outline">
                        <input type="text" id="typeExp" class="form-control form-control-lg" placeholder="MM/YYYY"
                          size="7" id="exp" minlength="7" maxlength="7" name="date_expiration"/>
                      </div>
                      <!-- CVV -->
                      <div class="form-outline">
                        <input type="password" id="typeText2" class="form-control form-control-lg"
                           size="1" minlength="3" maxlength="3" placeholder="Cvv" name="cvv"/>
                      </div>
                      <br>
                      <div class="form-outline">
                        <label class="form-label" for="typeText2">  </label>
                        <button type="button" class="btn btn-info btn-lg btn-rounded">
                        <i class="fas fa-arrow-right"></i>
                      </button>
                      </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center pd-2" >
                        <!-- <p class="form-label" for="typeExp">Scan QR Code</p> -->
                        <!-- <br><br> -->
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAe1BMVEX///8AAACsrKzS0tJKSkq8vLyGhoaKioosLCz4+PjLy8s8PDzDw8Py8vKBgYG0tLRtbW2cnJzZ2dlXV1fs7OwXFxd3d3fm5uaTk5Pg4OCwsLCmpqa/v78SEhIvLy8nJyc2NjZDQ0NfX19ycnJnZ2dQUFAdHR2fn59dXV2M/xlNAAAILUlEQVR4nO2d53bqOhCFIbSYXkwnBELa+z/hXaDZOdG+HiSbEp+c2f9UrY9kqc5IlYrJZDKZTCaTyWQymfJrvH4ooIaUXvql18pH2pKcnG9Lo0hT1uMA4bpaRB20ieIVhKYk9863pVOoLdrPCj0UqrWej7AVR1gv1JYHIzRCIzTCo5rnk+9DWG81w2od4giTl+F3vTbGJy1nLjwLEB6i2oLcsYStQD6ncRxhj6K7kn3ngs8BwtAY7oR//VjCZlSttcsIZUh/VGoHYS2qLfjXN0Ij9GWE/zzh3gW3Su33Iaxmq1aIEENQq3pWWG0SYU3JboRGaIRGaIR/GWG7Pvmu+nJ+EpYg/fQUTPt+ZU+ffql2iQlZT0pxX5EjfikJH6MII2dtRmiERmiEmXr/dYTz1eCoVSrhj1GWPibZhKmUnpeYEHOadlbVf0RzGhC2JVzmOY0RGqERGuHtCQdXIRzclbCWrV42YSrJo8PsqGHghJQIe1IaoykR9pS2XEh4XtqcBkvcfISsMu55Q0ZohE5G6MsIIRAexkrf7GkVIAw0JpJwFdOUMexCbm1PMz3qa8TfPR2DT3sJdiVZOSFtSzLPafLpPhZDIJRdDBhndiVZJXQyQiM0QiPMEjrL6xLub0LY6NTzaz8Egivd6fbSoxIibEtyQ5KJsIbSEh7uC7Sl06jcQ3RA2KHkyBG/zAoQRs7ayiwjNMLy658n/NG+dNk4aUCuEMmgkUPdF0LouniYpG8WJ42efcLUr2VA6+dU2oDDt3b2x5cBQviukX38vHoN8caBMqeBUj83NhRWElYmdbG+azchZBeHYoTYEqdzVih2XmqERmiEv5RQ6UthuRcghIUjlkef2R+5sC/t19pZYrtS0lZKDfqemmJuM2268Mjlqs2IcOaShxL96bI3yRxpIh+Z/48pF+FHdil2qCDxGl9RX7ItiPB8KWiY0a4ChKPsUqkRGqERGmEOQqwtaA2CzlIhDPSlf86eogjZmT2O8DWSsJKcVJk9P37Xs0K4c6kTV+zLnqYrYQxZ21O294VEYwWcuo/h9+l7TUgqE9eGrSQfpPRIwsvEU+3JfWTFRIowvJKYUNwNArv6EHuUyB8pIUKIFoBwagchDe2Y8oRmbTkJp0ZohEb444S/oKfpeNry4mt/it5hLALhJukdlRBhX6IXu1Oxx/kp2EsfXS0LqvzVZcN1UUw47n1XgtVlXsLI7EQYEA4I5Qd4CtSqECoqFWHgxgEjNEIjNMIrEMotSu9xhIfbELa7Wdpg6Ubxq2brpL2UliCESkG4cNEYB9ONq/zr+ExqdbU0sSzqUq2iWUFCRTBqpWi0FQtAqhSDcreSKbYY6mTXomh5G8JpNqFiI8w2UQFCmbVN41p8pXmpERqhEd6R8FA9K6UvxQIQPTcRbs4T1ig5X18KwtDpWtsNNovAHb4gpPEQ+8hjGTapchnwuh9uBOvj4si+P1y+umCzIbVK6bnL1mT3Cyk9ktyxp2sBxTl5aFLW+Cyy6eEzYAi/S+THy0QYOOUmwrznFkZohEZYesK4i2810a3zGiGNpiBkY3yJPlTiFEm47VygrWynYjQA4Uy2U/Enluw4fQThI1Un0VOpnP/EBQkvE81peM974efGdqrmj0+6jc9MTuUjxLzUCEVGaIRXUSl6Gt8UA9q+K8kSPd1mFqPkKQjFiqLnrCiem2JsAUIpvJN87anfBmjrm4vEEio2/djypREffwXF3AbJfED47P+R2L4UI74EMaR/UDaJjt1NVGyiIBjM0KwNNlGMIOL7S6FIG2EJarv6Eh27i2GERmiEfyshEHIS0ukaE5Jt4o0IxRgfRG1nNz9b+sldsb7H0m0s8RJMxNr+g0z8Wy4a4EzYkGwSfBFj/HXft9WX6IaLngXuGfsfoQS16zslmR0MlR1hti+lZCZUhAUg+Vvk3U0kwomSnay+oMCuPkQbojkJyWemqBW0ERqhEd6fkP2Aq9kIFT+Z+1KFUBvw7krIvtziIK0NMnDeluC45by0V1KLRCcSjUPJxSbTWRuErU2Wj/ZmdB3Cy6TcX8ruGMrvBUI+dhQFPCxLRRh5yk0ywqtRnJMRGuHfQ6gsHyGls8xJSM4KsWuLy+76AqFUsqO3gvrujq9UufSTCeWurzeFUCqDvi4SCxBe5742SHkNSZFyXxvveSsHhHnX+PmU872nSEKy+jJCIzTCnyP8xT3Nm7uFGE8+X5mw2F3Qkf4WkGJPEzniQ1T6vm/JGqERGqERlpUwcifqSoTKMKG8MwPCl5kndm34nHnP0DDhKHukQtOYcOh/S1leq4TKrx94DYlWwIzQPp8cUMi88i6E+XYxjNAIjdAIixAGdhO5Q89HGHsR1E0J++4B0gWtD18ap4dGB2t6mFSSPyVZ1BBzmyc/esVmkwuvrkXIFeQn31bneVSkhyXVUubX45UbeIzQCI3QCD3CAWW7jDDSl/uuhMn8pBQLwgDh2GWHlT0I12+To+qSDOfscX2SqbsSQmQxpBEq97Xx/aUV/2MBGaERGqER/jbCio8AQsWXO0CI47MrE55XiJAUOD/URLUE3kb4BYRXet/CCJ2M0AjjdBvCuMagA/8RwrfLCOutZlgtrJJA2BuftMSdVkOn1zhCKf0lmDC+DL/rdSUfaXrRw8+chPmkrYAlmkd8RYG3gqBRdnJeX+5ihNexGIokLHiftxEaoRH+POG6WkTwXQsQBqYRkYRYXCmEoZshx+uHAsKCZumXxscSiQ64Wc+ptGLSX5Nk8u1LXen1ZdeQmUwmk8lkMplMJtO/qv8AC3n2hgizeL0AAAAASUVORK5CYII=" alt="QR Code">
                    </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
</body>
</html>